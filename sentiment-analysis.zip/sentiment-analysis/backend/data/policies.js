module.exports = [
  {
    id: 'ladli-behna-yojana',
    title: 'Ladli Behna Yojana',
    category: 'Women and Family Support',
    description: 'A Madhya Pradesh state initiative that provides financial support to eligible women under current state rules.',
    intendedFor: 'Women who meet the current Madhya Pradesh scheme criteria.',
    feedbackTopics: ['Application and verification support', 'Payment timing and status updates', 'Access to clear scheme information']
  },
  {
    id: 'ayushman-yojana',
    title: 'Ayushman Yojana',
    category: 'Healthcare',
    description: 'Ayushman Bharat PM-JAY helps eligible families access hospital care through participating providers, subject to scheme rules.',
    intendedFor: 'Families identified as eligible under the applicable national and state program rules.',
    feedbackTopics: ['Checking eligibility and getting a health card', 'Finding participating hospitals', 'Access to covered treatment and support']
  },
  {
    id: 'pradhan-mantri-awas-yojana',
    title: 'Pradhan Mantri Awas Yojana',
    category: 'Housing',
    description: 'Pradhan Mantri Awas Yojana supports access to housing through urban and rural program components, with assistance governed by their respective rules.',
    intendedFor: 'Eligible households applying through the relevant urban or rural component.',
    feedbackTopics: ['Application and beneficiary-list information', 'Approval and construction progress', 'Access to local implementation support']
  },
  {
    id: 'sukanya-samriddhi-yojana',
    title: 'Sukanya Samriddhi Yojana',
    category: 'Savings',
    description: 'A government-backed savings scheme that helps families build long-term savings for a girl child through an eligible account.',
    intendedFor: 'Families opening and maintaining an account for a girl child under current account rules.',
    feedbackTopics: ['Opening an account through a bank or post office', 'Understanding deposits and account rules', 'Access to account statements and service']
  },
  {
    id: 'atal-pension-yojana',
    title: 'Atal Pension Yojana',
    category: 'Pension',
    description: 'A contributory pension scheme designed to provide retirement income, with participation and pension terms set by current rules.',
    intendedFor: 'People who meet the current enrollment requirements and choose a contribution option.',
    feedbackTopics: ['Enrollment and contribution guidance', 'Understanding pension options and statements', 'Support for account changes and service requests']
  },
  {
    id: 'pm-kisan-samman-nidhi',
    title: 'PM Kisan Samman Nidhi',
    category: 'Agriculture',
    description: 'PM-KISAN provides income support to eligible farmer families through direct benefit transfers under scheme guidelines.',
    intendedFor: 'Farmer families that meet the scheme criteria and complete the required land and identity verification.',
    feedbackTopics: ['Registration and beneficiary-status checks', 'e-KYC and record correction support', 'Payment status and bank-account issues']
  },
  {
    id: 'pm-jan-dhan-yojana',
    title: 'PM Jan Dhan Yojana',
    category: 'Financial Inclusion',
    description: 'Pradhan Mantri Jan-Dhan Yojana promotes access to basic banking services and financial inclusion.',
    intendedFor: 'People seeking access to a basic bank account and related financial services.',
    feedbackTopics: ['Opening and activating an account', 'Access to banking services and support', 'Understanding account features and linked services']
  }
];