const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema(
  {
    text: {
      type: String,
      required: [true, 'Comment text is required'],
      trim: true,
      maxlength: [5000, 'Comment text cannot exceed 5000 characters']
    },
    sentiment: {
      type: String,
      required: [true, 'Sentiment classification is required'],
      enum: {
        values: ['Positive', 'Negative', 'Neutral'],
        message: '{VALUE} is not a valid sentiment'
      },
      index: true
    },
    topic: {
      type: String,
      required: true,
      enum: {
        values: ['Healthcare', 'Education', 'Transportation', 'Public Services', 'Other'],
        message: '{VALUE} is not a valid topic'
      },
      default: 'Other',
      index: true
    },
    emotion: {
      type: String,
      required: true,
      enum: {
        values: ['Happy', 'Angry', 'Sad', 'Neutral', 'Concerned'],
        message: '{VALUE} is not a valid emotion'
      },
      default: 'Neutral',
      index: true
    },
    priority: {
      type: String,
      required: true,
      enum: {
        values: ['High', 'Medium', 'Low'],
        message: '{VALUE} is not a valid priority'
      },
      default: 'Medium',
      index: true
    },
    confidence: {
      type: Number,
      min: 0,
      max: 100,
      default: 85
    },
    keywords: {
      type: [String],
      default: []
    },
    summary: {
      type: String,
      default: ''
    },
    policyId: {
      type: String,
      default: '',
      index: true
    },
    policyTitle: {
      type: String,
      default: ''
    },
    userId: {
      type: String,
      required: true,
      index: true
    },
    createdAt: {
      type: Date,
      default: Date.now,
      index: true
    }
  },
  {
    timestamps: true
  }
);

// Compound index for fast filtering and stats
commentSchema.index({ createdAt: -1, sentiment: 1, topic: 1 });

const Comment = mongoose.models.Comment || mongoose.model('Comment', commentSchema);

module.exports = Comment;
