const { GoogleGenerativeAI } = require('@google/generative-ai');

/**
 * Intelligent rule-based fallback analyzer when Gemini API key is missing or encounters network errors.
 */
function fallbackAnalyze(text) {
  const lower = text.toLowerCase();

  // 1. Topic detection
  let topic = 'Other';
  const topicKeywords = {
    Healthcare: ['hospital', 'doctor', 'nurse', 'clinic', 'medicine', 'health', 'medical', 'surgery', 'ambulance', 'patient', 'bed', 'pharmacy', 'treatment'],
    Education: ['school', 'university', 'college', 'teacher', 'student', 'education', 'classroom', 'tuition', 'exam', 'syllabus', 'books', 'scholarship'],
    Transportation: ['bus', 'train', 'metro', 'transit', 'traffic', 'road', 'highway', 'commute', 'subway', 'station', 'fare', 'pothole', 'driver', 'route'],
    'Public Services': ['water', 'electricity', 'power', 'garbage', 'trash', 'sanitation', 'park', 'police', 'council', 'permit', 'drainage', 'lighting', 'sewage']
  };

  for (const [top, words] of Object.entries(topicKeywords)) {
    if (words.some(w => lower.includes(w))) {
      topic = top;
      break;
    }
  }

  // 2. Sentiment & Emotion detection
  const positiveWords = ['great', 'good', 'excellent', 'love', 'happy', 'pleased', 'fantastic', 'wonderful', 'thanks', 'thank', 'appreciate', 'helpful', 'prompt', 'clean', 'improved', 'best', 'superb', 'efficient', 'impressive'];
  const negativeAngryWords = ['terrible', 'awful', 'angry', 'worst', 'disgusting', 'rude', 'unacceptable', 'furious', 'outraged', 'horrible', 'corrupt', 'harassment', 'scam'];
  const negativeSadWords = ['disappointed', 'sad', 'unhappy', 'depressed', 'grief', 'regret', 'neglect', 'abandoned', 'hopeless'];
  const concernedWords = ['concern', 'concerned', 'worry', 'worried', 'danger', 'dangerous', 'unsafe', 'risk', 'hazard', 'urgent', 'critical', 'issue', 'problem', 'delay', 'broken'];

  let posCount = positiveWords.filter(w => lower.includes(w)).length;
  let angryCount = negativeAngryWords.filter(w => lower.includes(w)).length;
  let sadCount = negativeSadWords.filter(w => lower.includes(w)).length;
  let concernCount = concernedWords.filter(w => lower.includes(w)).length;

  let sentiment = 'Neutral';
  let emotion = 'Neutral';

  if (posCount > (angryCount + sadCount + concernCount)) {
    sentiment = 'Positive';
    emotion = 'Happy';
  } else if (angryCount > 0 || sadCount > 0 || concernCount > 0) {
    sentiment = 'Negative';
    if (angryCount >= sadCount && angryCount >= concernCount) {
      emotion = 'Angry';
    } else if (sadCount > angryCount && sadCount >= concernCount) {
      emotion = 'Sad';
    } else {
      emotion = 'Concerned';
    }
  } else {
    sentiment = 'Neutral';
    emotion = 'Neutral';
  }

  // 3. Priority detection
  let priority = 'Medium';
  const highPriorityWords = ['urgent', 'emergency', 'danger', 'hazard', 'critical', 'injury', 'severe', 'immediate', 'leak', 'accident', 'fire', 'life'];
  if (highPriorityWords.some(w => lower.includes(w)) || emotion === 'Angry') {
    priority = 'High';
  } else if (sentiment === 'Positive' && !lower.includes('need') && !lower.includes('require')) {
    priority = 'Low';
  }

  // 4. Keyword extraction
  const stopWords = new Set(['the', 'and', 'is', 'in', 'to', 'of', 'for', 'a', 'an', 'at', 'on', 'this', 'that', 'with', 'by', 'as', 'are', 'was', 'were', 'it', 'from', 'be', 'or', 'we', 'our', 'my', 'i', 'has', 'have', 'had', 'very', 'too']);
  const words = lower.replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length > 3 && !stopWords.has(w));
  const uniqueKeywords = Array.from(new Set(words)).slice(0, 4);

  // 5. Summary
  const firstSentence = text.split(/[.!?]/)[0].trim();
  const summary = firstSentence.length > 10 ? firstSentence.slice(0, 120) + (firstSentence.length > 120 ? '...' : '.') : `Feedback regarding ${topic} expressing ${sentiment.toLowerCase()} sentiment.`;

  return {
    sentiment,
    topic,
    emotion,
    priority,
    confidence: 88,
    keywords: uniqueKeywords.length > 0 ? uniqueKeywords : [topic.toLowerCase(), sentiment.toLowerCase()],
    summary
  };
}

/**
 * Normalizes and validates the AI JSON output to conform strictly to schema.
 */
function normalizeAiResponse(data, originalText) {
  const validSentiments = ['Positive', 'Negative', 'Neutral'];
  const validTopics = ['Healthcare', 'Education', 'Transportation', 'Public Services', 'Other'];
  const validEmotions = ['Happy', 'Angry', 'Sad', 'Neutral', 'Concerned'];
  const validPriorities = ['High', 'Medium', 'Low'];

  // Normalize sentiment
  let sentiment = validSentiments.find(s => s.toLowerCase() === (data.sentiment || '').toLowerCase()) || 'Neutral';

  // Normalize topic
  let topic = validTopics.find(t => t.toLowerCase() === (data.topic || '').toLowerCase()) || 'Other';

  // Normalize emotion
  let emotion = validEmotions.find(e => e.toLowerCase() === (data.emotion || '').toLowerCase()) || 'Neutral';

  // Normalize priority
  let priority = validPriorities.find(p => p.toLowerCase() === (data.priority || '').toLowerCase()) || 'Medium';

  // Confidence
  let confidence = Number(data.confidence);
  if (isNaN(confidence) || confidence < 0 || confidence > 100) {
    confidence = 90;
  }

  // Keywords
  let keywords = Array.isArray(data.keywords) ? data.keywords.map(k => String(k).trim()).filter(Boolean).slice(0, 6) : [];

  // Summary
  let summary = typeof data.summary === 'string' && data.summary.trim() ? data.summary.trim() : originalText.slice(0, 100);

  return {
    sentiment,
    topic,
    emotion,
    priority,
    confidence: Math.round(confidence),
    keywords,
    summary
  };
}

/**
 * Analyzes comment text using Google Gemini 1.5 Flash.
 * Falls back safely to rule-based classification if API is unavailable.
 */
async function analyzeComment(text) {
  if (!text || typeof text !== 'string' || !text.trim()) {
    throw new Error('Comment text is required for sentiment analysis');
  }

  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey || apiKey === 'your_gemini_api_key_here' || apiKey.trim() === '') {
    console.warn('[AI Service] GEMINI_API_KEY is not configured. Utilizing intelligent fallback heuristic analysis.');
    return fallbackAnalyze(text);
  }

  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

    const prompt = `Analyze this e-consultation feedback comment and return ONLY valid JSON (no markdown, no backticks):
Comment: "${text.replace(/"/g, '\\"')}"

Return this exact JSON structure:
{
  "sentiment": "Positive" or "Negative" or "Neutral",
  "topic": "Healthcare" or "Education" or "Transportation" or "Public Services" or "Other",
  "emotion": "Happy" or "Angry" or "Sad" or "Neutral" or "Concerned",
  "priority": "High" or "Medium" or "Low",
  "confidence": <number 0-100>,
  "keywords": ["word1", "word2", "word3"],
  "summary": "<one sentence summary>"
}`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    let rawText = response.text().trim();

    // Clean possible markdown code fences
    if (rawText.startsWith('```json')) {
      rawText = rawText.replace(/^```json\s*/i, '').replace(/\s*```$/i, '').trim();
    } else if (rawText.startsWith('```')) {
      rawText = rawText.replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim();
    }

    const parsed = JSON.parse(rawText);
    return normalizeAiResponse(parsed, text);
  } catch (err) {
    console.error('[AI Service] Gemini API call error:', err.message);
    console.warn('[AI Service] Falling back to intelligent heuristic analysis.');
    return fallbackAnalyze(text);
  }
}

module.exports = {
  analyzeComment,
  fallbackAnalyze
};
