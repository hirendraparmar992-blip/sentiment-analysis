const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const COOKIE_NAME = 'consultation_session';
const TOKEN_SECRET = process.env.AUTH_TOKEN_SECRET || (
  process.env.NODE_ENV === 'production' ? '' : crypto.randomBytes(32).toString('hex')
);

if (!TOKEN_SECRET) {
  throw new Error('AUTH_TOKEN_SECRET must be set in production.');
}

const cookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax',
  path: '/',
  maxAge: 7 * 24 * 60 * 60 * 1000
};

function issueSession(res, user) {
  const token = jwt.sign(
    { email: user.email, name: user.name },
    TOKEN_SECRET,
    { subject: String(user._id), expiresIn: '7d' }
  );
  res.cookie(COOKIE_NAME, token, cookieOptions);
}

function clearSession(res) {
  const { maxAge, ...clearOptions } = cookieOptions;
  res.clearCookie(COOKIE_NAME, clearOptions);
}

function authenticateToken(token) {
  if (!token) return null;

  try {
    const payload = jwt.verify(token, TOKEN_SECRET);
    return { id: payload.sub, email: payload.email, name: payload.name };
  } catch {
    return null;
  }
}

function requireAuth(req, res, next) {
  const user = authenticateToken(req.cookies && req.cookies[COOKIE_NAME]);
  if (!user) {
    return res.status(401).json({ success: false, message: 'Please sign in to continue.' });
  }

  req.user = user;
  next();
}

module.exports = { COOKIE_NAME, authenticateToken, clearSession, issueSession, requireAuth };