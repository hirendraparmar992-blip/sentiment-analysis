const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Comment = require('../models/Comment');
const { analyzeComment } = require('../services/aiAnalysis');
const { requireAuth } = require('../middleware/auth');
const policies = require('../data/policies');

router.use(requireAuth);

// In-memory fallback dataset in case MongoDB is not running or during initial development
let memoryComments = [
  {
    _id: 'mem_1',
    text: 'The new express bus route through the downtown tech corridor has cut my daily commute by 25 minutes! Extremely satisfied with the punctual service.',
    sentiment: 'Positive',
    topic: 'Transportation',
    emotion: 'Happy',
    priority: 'Low',
    confidence: 96,
    keywords: ['express bus', 'commute', 'punctual', 'satisfied'],
    summary: 'Citizen commends the new downtown express bus route for reducing commute times.',
    createdAt: new Date(Date.now() - 1000 * 60 * 18)
  },
  {
    _id: 'mem_2',
    text: 'Urgent: The street lights along Maple Avenue and 5th Street have been completely non-functional for 4 days. It is pitch dark and hazardous for pedestrians.',
    sentiment: 'Negative',
    topic: 'Public Services',
    emotion: 'Concerned',
    priority: 'High',
    confidence: 93,
    keywords: ['street lights', 'hazardous', 'pedestrians', 'urgent'],
    summary: 'Safety alert regarding broken street lighting on Maple Avenue creating pedestrian hazards.',
    createdAt: new Date(Date.now() - 1000 * 60 * 45)
  },
  {
    _id: 'mem_3',
    text: 'Doctors and nursing staff at the General District Hospital emergency ward were compassionate and professional during our visit yesterday.',
    sentiment: 'Positive',
    topic: 'Healthcare',
    emotion: 'Happy',
    priority: 'Low',
    confidence: 95,
    keywords: ['hospital', 'emergency ward', 'compassionate', 'professional'],
    summary: 'Praise for compassionate and professional healthcare staff at District Hospital.',
    createdAt: new Date(Date.now() - 1000 * 60 * 120)
  },
  {
    _id: 'mem_4',
    text: 'The public school digital portal crashed continuously during semester enrollment. Parents could not register classes, completely unacceptable!',
    sentiment: 'Negative',
    topic: 'Education',
    emotion: 'Angry',
    priority: 'High',
    confidence: 94,
    keywords: ['portal crash', 'enrollment', 'unacceptable', 'school'],
    summary: 'Complaint concerning digital enrollment portal failure preventing student class registration.',
    createdAt: new Date(Date.now() - 1000 * 60 * 240)
  },
  {
    _id: 'mem_5',
    text: 'The proposed recycling schedule changes seem reasonable, but we need more clarity on bi-weekly hazardous waste disposal guidelines.',
    sentiment: 'Neutral',
    topic: 'Public Services',
    emotion: 'Neutral',
    priority: 'Medium',
    confidence: 88,
    keywords: ['recycling', 'schedule', 'hazardous waste', 'clarity'],
    summary: 'Citizen seeks clearer guidelines on the proposed bi-weekly recycling schedule.',
    createdAt: new Date(Date.now() - 1000 * 60 * 360)
  },
  {
    _id: 'mem_6',
    text: 'Long wait times for routine cardiology appointments in our suburban health clinic continue to be an issue, though phone consultations have helped slightly.',
    sentiment: 'Negative',
    topic: 'Healthcare',
    emotion: 'Concerned',
    priority: 'Medium',
    confidence: 89,
    keywords: ['wait times', 'cardiology', 'clinic', 'consultations'],
    summary: 'Feedback highlighting long cardiology wait times offset partly by telemedicine.',
    createdAt: new Date(Date.now() - 1000 * 60 * 520)
  }
];

function isMongoConnected() {
  return mongoose.connection.readyState === 1;
}

/**
 * Calculate aggregated stats from an array of comment documents or objects.
 */
function calculateStats(comments) {
  const stats = {
    total: comments.length,
    positive: 0,
    negative: 0,
    neutral: 0,
    byTopic: {
      Healthcare: 0,
      Education: 0,
      Transportation: 0,
      'Public Services': 0,
      Other: 0
    },
    byEmotion: {
      Happy: 0,
      Angry: 0,
      Sad: 0,
      Neutral: 0,
      Concerned: 0
    },
    byPriority: {
      High: 0,
      Medium: 0,
      Low: 0
    }
  };

  comments.forEach(c => {
    // Sentiment
    if (c.sentiment === 'Positive') stats.positive++;
    else if (c.sentiment === 'Negative') stats.negative++;
    else stats.neutral++;

    // Topic
    if (stats.byTopic[c.topic] !== undefined) {
      stats.byTopic[c.topic]++;
    } else {
      stats.byTopic.Other = (stats.byTopic.Other || 0) + 1;
    }

    // Emotion
    if (stats.byEmotion[c.emotion] !== undefined) {
      stats.byEmotion[c.emotion]++;
    } else {
      stats.byEmotion.Neutral = (stats.byEmotion.Neutral || 0) + 1;
    }

    // Priority
    if (stats.byPriority[c.priority] !== undefined) {
      stats.byPriority[c.priority]++;
    } else {
      stats.byPriority.Medium = (stats.byPriority.Medium || 0) + 1;
    }
  });

  return stats;
}

/**
 * GET /api/comments
 * Fetch recent comments (sorted by createdAt desc, limit 100)
 */
router.get('/', async (req, res) => {
  try {
    const { topic, sentiment, priority, limit = 100 } = req.query;

    if (isMongoConnected()) {
      const query = {};
      if (topic) query.topic = topic;
      if (sentiment) query.sentiment = sentiment;
      if (priority) query.priority = priority;

      const comments = await Comment.find(query)
        .sort({ createdAt: -1 })
        .limit(Number(limit));

      return res.json({
        success: true,
        source: 'database',
        count: comments.length,
        data: comments
      });
    }

    // Fallback in-memory
    let filtered = [...memoryComments];
    if (topic) filtered = filtered.filter(c => c.topic === topic);
    if (sentiment) filtered = filtered.filter(c => c.sentiment === sentiment);
    if (priority) filtered = filtered.filter(c => c.priority === priority);

    filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return res.json({
      success: true,
      source: 'memory',
      count: filtered.length,
      data: filtered.slice(0, Number(limit))
    });
  } catch (err) {
    console.error('Error fetching comments:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch comments', error: err.message });
  }
});

/**
 * GET /api/comments/stats
 * Return aggregated stats across all feedback
 */
router.get('/stats', async (req, res) => {
  try {
    if (isMongoConnected()) {
      const allComments = await Comment.find({}, 'sentiment topic emotion priority');
      const stats = calculateStats(allComments);
      return res.json({ success: true, source: 'database', data: stats });
    }

    const stats = calculateStats(memoryComments);
    return res.json({ success: true, source: 'memory', data: stats });
  } catch (err) {
    console.error('Error fetching stats:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch stats', error: err.message });
  }
});

/**
 * POST /api/comments/analyze
 * Analyze comment with AI, save to MongoDB / store, emit 'new-comment' via socket.io
 */
router.post('/analyze', async (req, res) => {
  try {
    const { text, policyId } = req.body;

    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Feedback comment text is required'
      });
    }

    const selectedPolicy = policyId ? policies.find(policy => policy.id === policyId) : null;
    if (policyId && !selectedPolicy) {
      return res.status(400).json({ success: false, message: 'Select a valid policy proposal.' });
    }

    // Perform AI analysis
    const analysis = await analyzeComment(text.trim());

    let savedComment;
    if (isMongoConnected()) {
      const commentDoc = new Comment({
        text: text.trim(),
        sentiment: analysis.sentiment,
        topic: analysis.topic,
        emotion: analysis.emotion,
        priority: analysis.priority,
        confidence: analysis.confidence,
        keywords: analysis.keywords,
        summary: analysis.summary,
        policyId: selectedPolicy ? selectedPolicy.id : '',
        policyTitle: selectedPolicy ? selectedPolicy.title : '',
        userId: req.user.id,
        createdAt: new Date()
      });
      savedComment = await commentDoc.save();
    } else {
      savedComment = {
        _id: 'mem_' + Date.now(),
        text: text.trim(),
        ...analysis,
        policyId: selectedPolicy ? selectedPolicy.id : '',
        policyTitle: selectedPolicy ? selectedPolicy.title : '',
        userId: req.user.id,
        createdAt: new Date()
      };
      memoryComments.unshift(savedComment);
    }

    // Real-time broadcast via Socket.io
    const io = req.app.get('io');
    if (io) {
      io.emit('new-comment', savedComment);

      // Also compute and emit fresh stats
      let freshStats;
      if (isMongoConnected()) {
        const allComments = await Comment.find({}, 'sentiment topic emotion priority');
        freshStats = calculateStats(allComments);
      } else {
        freshStats = calculateStats(memoryComments);
      }
      io.emit('stats-update', freshStats);
    }

    return res.status(201).json({
      success: true,
      message: 'Comment analyzed and recorded successfully',
      data: savedComment
    });
  } catch (err) {
    console.error('Error analyzing comment:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to analyze comment',
      error: err.message
    });
  }
});

/**
 * DELETE /api/comments/:id
 * Delete a comment by ID
 */
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    let deleted = false;
    if (isMongoConnected()) {
      if (mongoose.Types.ObjectId.isValid(id)) {
        const result = await Comment.findOneAndDelete({ _id: id, userId: req.user.id });
        deleted = !!result;
      }
    } else {
      const idx = memoryComments.findIndex(c =>
        String(c._id) === String(id) && String(c.userId) === String(req.user.id)
      );
      if (idx !== -1) {
        memoryComments.splice(idx, 1);
        deleted = true;
      }
    }

    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Comment not found' });
    }

    // Broadcast deletion and fresh stats via Socket.io
    const io = req.app.get('io');
    if (io) {
      io.emit('comment-deleted', { id });
      let freshStats;
      if (isMongoConnected()) {
        const allComments = await Comment.find({}, 'sentiment topic emotion priority');
        freshStats = calculateStats(allComments);
      } else {
        freshStats = calculateStats(memoryComments);
      }
      io.emit('stats-update', freshStats);
    }

    return res.json({ success: true, message: 'Comment deleted successfully', id });
  } catch (err) {
    console.error('Error deleting comment:', err);
    return res.status(500).json({ success: false, message: 'Failed to delete comment', error: err.message });
  }
});

module.exports = {
  router,
  calculateStats,
  memoryComments
};
