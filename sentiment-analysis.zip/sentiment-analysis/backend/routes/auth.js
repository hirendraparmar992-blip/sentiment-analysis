const crypto = require('crypto');
const express = require('express');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const User = require('../models/User');
const { clearSession, issueSession, requireAuth } = require('../middleware/auth');

const router = express.Router();
const memoryUsers = new Map();

function isMongoConnected() {
  return mongoose.connection.readyState === 1;
}

function publicUser(user) {
  return { id: String(user._id), name: user.name, email: user.email };
}

async function findUserByEmail(email) {
  if (isMongoConnected()) return User.findOne({ email }).select('+passwordHash');
  return memoryUsers.get(email) || null;
}

router.post('/register', async (req, res) => {
  try {
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';

    if (name.length < 2 || name.length > 80) {
      return res.status(400).json({ success: false, message: 'Enter a name between 2 and 80 characters.' });
    }
    if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ success: false, message: 'Enter a valid email address.' });
    }
    if (password.length < 8 || password.length > 128) {
      return res.status(400).json({ success: false, message: 'Password must be between 8 and 128 characters.' });
    }
    if (await findUserByEmail(email)) {
      return res.status(409).json({ success: false, message: 'An account with that email already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const user = isMongoConnected()
      ? await User.create({ name, email, passwordHash })
      : { _id: crypto.randomUUID(), name, email, passwordHash };

    if (!isMongoConnected()) memoryUsers.set(email, user);
    issueSession(res, user);
    return res.status(201).json({ success: true, user: publicUser(user) });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: 'An account with that email already exists.' });
    }
    console.error('Registration failed:', error.message);
    return res.status(500).json({ success: false, message: 'Could not create the account.' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    const user = await findUserByEmail(email);

    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ success: false, message: 'Email or password is incorrect.' });
    }

    issueSession(res, user);
    return res.json({ success: true, user: publicUser(user) });
  } catch (error) {
    console.error('Login failed:', error.message);
    return res.status(500).json({ success: false, message: 'Could not sign in right now.' });
  }
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ success: true, user: req.user });
});

router.post('/logout', (req, res) => {
  clearSession(res);
  res.json({ success: true });
});

module.exports = { router, memoryUsers };