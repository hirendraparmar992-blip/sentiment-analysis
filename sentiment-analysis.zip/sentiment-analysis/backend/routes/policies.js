const express = require('express');
const policies = require('../data/policies');

const router = express.Router();

router.get('/', (req, res) => {
  res.json({ success: true, data: policies });
});

module.exports = router;