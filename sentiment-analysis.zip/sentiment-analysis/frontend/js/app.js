/**
 * E-Consultation AI Sentiment Analysis Frontend Application
 * Real-time WebSocket + REST API Single Page Application
 */

// Global Application State
const state = {
  socket: null,
  comments: [],
  filteredComments: [],
  stats: {
    total: 0,
    positive: 0,
    negative: 0,
    neutral: 0,
    byTopic: {
      Healthcare: 0,
      Education: 0,
      Transportation: 0,
      'Public Services': 0,
      Other: 0
    },
    byEmotion: {
      Happy: 0,
      Angry: 0,
      Sad: 0,
      Neutral: 0,
      Concerned: 0
    },
    byPriority: {
      High: 0,
      Medium: 0,
      Low: 0
    }
  },
  policies: [],
  user: null,
  authMode: 'login',
  appInitialized: false,
  activePolicyId: '',
  activeSection: 'dashboard',
  recentFilter: 'all',
  unreadNotifications: 0
};

// Backend API URL (relies on same host or port 3001)
const isLocalFrontend = ['localhost', '127.0.0.1'].includes(window.location.hostname) &&
  window.location.port !== '3001';
const API_BASE = isLocalFrontend ? 'http://localhost:3001' : window.location.origin;

// Preset sample comments for testing
const SAMPLE_PRESETS = {
  1: 'The new electric bus fleet on Line 14 has drastically cut carbon emissions and improved our morning commute punctuality. Excellent work by the city transit team!',
  2: 'The emergency wing at Central Hospital was heavily understaffed last night. My elderly mother waited over 3 hours just to get triage vitals recorded. This is unacceptable.',
  3: 'Our local elementary school science lab is missing basic equipment and textbooks. Parents are forced to fundraise privately for fundamental learning materials.',
  4: 'Major potholes and unpaved trenches along Elm Avenue are damaging vehicles and pose severe safety hazards for cyclists and pedestrians.',
  5: 'The renovated community park is clean, accessible, and has a wonderful new play area. Thank you for making this a welcoming space for families.',
  6: 'It is difficult to get a timely appointment at the neighborhood clinic, and residents need clearer information about available walk-in services.',
  7: 'Could the public library extend its weekend hours during the school year so students have more time to study?',
  8: 'Several homes on Cedar Street have had low water pressure for a week, and our service requests have not received a response.'
};

/**
 * Initialize application on DOM content loaded
 */
document.addEventListener('DOMContentLoaded', () => {
  initAuth();
  checkAuthentication();
});

function initAuth() {
  const authForm = document.getElementById('authForm');
  const modeToggle = document.getElementById('authModeToggle');
  const signOutButton = document.getElementById('signOutBtn');

  authForm.addEventListener('submit', handleAuthSubmit);
  modeToggle.addEventListener('click', toggleAuthMode);
  signOutButton.addEventListener('click', handleSignOut);
}

async function checkAuthentication() {
  try {
    const response = await fetch(`${API_BASE}/api/auth/me`, { credentials: 'include' });
    if (!response.ok) throw new Error('No active session');
    const result = await response.json();
    enterApplication(result.user);
  } catch {
    showAuthScreen();
  }
}

function showAuthScreen(message = '') {
  document.getElementById('authScreen').hidden = false;
  document.getElementById('appLayout').hidden = true;
  const error = document.getElementById('authError');
  error.textContent = message;
  error.hidden = !message;
}

function toggleAuthMode() {
  state.authMode = state.authMode === 'login' ? 'register' : 'login';
  const registering = state.authMode === 'register';
  const nameGroup = document.getElementById('authNameGroup');
  const nameInput = document.getElementById('authName');
  const passwordInput = document.getElementById('authPassword');

  nameGroup.hidden = !registering;
  nameInput.required = registering;
  passwordInput.autocomplete = registering ? 'new-password' : 'current-password';
  document.getElementById('authTitle').textContent = registering ? 'Create your account' : 'Welcome back';
  document.getElementById('authCopy').textContent = registering
    ? 'Create an account to take part in local policy consultations.'
    : 'Sign in to share feedback on local policy proposals.';
  document.getElementById('authSubmitBtn').textContent = registering ? 'Create account' : 'Sign in';
  document.getElementById('authModeToggle').textContent = registering
    ? 'Already have an account? Sign in'
    : 'New here? Create an account';
  document.getElementById('authError').hidden = true;
}

async function handleAuthSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const button = document.getElementById('authSubmitBtn');
  const error = document.getElementById('authError');
  const formData = new FormData(form);
  const body = {
    email: formData.get('email'),
    password: formData.get('password')
  };

  if (state.authMode === 'register') body.name = formData.get('name');
  button.disabled = true;
  error.hidden = true;

  try {
    const response = await fetch(`${API_BASE}/api/auth/${state.authMode}`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.message || 'Authentication failed.');
    form.reset();
    enterApplication(result.user);
  } catch (requestError) {
    error.textContent = requestError.message;
    error.hidden = false;
  } finally {
    button.disabled = false;
  }
}

async function handleSignOut() {
  try {
    await fetch(`${API_BASE}/api/auth/logout`, { method: 'POST', credentials: 'include' });
  } finally {
    if (state.socket) state.socket.disconnect();
    state.socket = null;
    state.user = null;
    state.appInitialized = false;
    if (state.authMode === 'register') toggleAuthMode();
    document.getElementById('authForm').reset();
    showAuthScreen();
  }
}

function enterApplication(user) {
  state.user = user;
  document.getElementById('authScreen').hidden = true;
  document.getElementById('appLayout').hidden = false;
  document.getElementById('authenticatedUserName').textContent = user.name;
  document.getElementById('authenticatedUserEmail').textContent = user.email;
  document.getElementById('userAvatar').textContent = user.name
    .split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase();

  if (state.appInitialized) return;
  state.appInitialized = true;
  initNavigation();
  initSocket();
  loadDashboardStats();
  loadRecentComments();
  loadPolicies();

  // Polling fallback every 30 seconds
  setInterval(() => {
    loadDashboardStats();
    loadRecentComments(false);
  }, 30000);

  // Mobile menu toggle
  const mobileBtn = document.getElementById('mobileMenuBtn');
  if (mobileBtn) {
    mobileBtn.addEventListener('click', () => {
      document.querySelector('.sidebar').classList.toggle('open');
    });
  }
}

async function loadPolicies() {
  const grid = document.getElementById('policyCardsGrid');
  const select = document.getElementById('policySelect');

  try {
    const response = await fetch(`${API_BASE}/api/policies`, { credentials: 'include' });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error('Could not load policy proposals.');

    state.policies = result.data;
    select.innerHTML = '<option value="">General consultation feedback</option>' +
      state.policies.map(policy => `<option value="${escapeHtml(policy.id)}">${escapeHtml(policy.title)}</option>`).join('');
    grid.innerHTML = state.policies.map(policy => `
      <article class="card policy-card">
        <span class="policy-category">${escapeHtml(policy.category)}</span>
        <h2 class="policy-title">${escapeHtml(policy.title)}</h2>
        <p class="policy-description">${escapeHtml(policy.description)}</p>
        <div class="policy-detail">
          <h3 class="policy-detail-label">Who it serves</h3>
          <p class="policy-detail-copy">${escapeHtml(policy.intendedFor)}</p>
        </div>
        <div class="policy-detail">
          <h3 class="policy-detail-label">Feedback topics</h3>
          <ul class="policy-feedback-topics">
            ${policy.feedbackTopics.map(topic => `<li>${escapeHtml(topic)}</li>`).join('')}
          </ul>
        </div>
        <button class="btn btn-outline" type="button" data-policy-id="${escapeHtml(policy.id)}">
          <i class="fa-regular fa-comment-dots"></i><span>Give feedback</span>
        </button>
      </article>
    `).join('');

    grid.querySelectorAll('[data-policy-id]').forEach(button => {
      button.addEventListener('click', () => startPolicyFeedback(button.dataset.policyId));
    });
    if (state.activePolicyId) select.value = state.activePolicyId;
  } catch (error) {
    grid.innerHTML = `<p class="policy-loading" role="alert">${escapeHtml(error.message)}</p>`;
  }
}

function startPolicyFeedback(policyId) {
  const policy = state.policies.find(item => item.id === policyId);
  if (!policy) return;
  state.activePolicyId = policyId;
  document.getElementById('policySelect').value = policyId;
  navigateTo('analyze');
  document.getElementById('feedbackText').focus();
}

/**
 * Single-Page App Navigation
 */
function initNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetSection = link.getAttribute('data-section');
      navigateTo(targetSection);

      // On mobile, close sidebar after clicking
      document.querySelector('.sidebar').classList.remove('open');
    });
  });
}

function navigateTo(sectionId) {
  state.activeSection = sectionId;

  // Update nav links active class
  document.querySelectorAll('.nav-link').forEach(link => {
    if (link.getAttribute('data-section') === sectionId) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Switch visible section
  document.querySelectorAll('.page-section').forEach(sec => {
    sec.classList.remove('active');
  });

  const activeElement = document.getElementById(`section-${sectionId}`);
  if (activeElement) {
    activeElement.classList.add('active');
  }

  // Update Breadcrumb
  const breadcrumb = document.getElementById('breadcrumbCurrent');
  if (breadcrumb) {
    const titles = {
      dashboard: 'Dashboard',
      analyze: 'Analyze Comment',
      comments: 'All Comments',
      topics: 'Topic Analysis',
      emotions: 'Emotion Analysis',
      priority: 'Priority Analysis',
      reports: 'Executive Reports',
      policies: 'Government Policies'
    };
    breadcrumb.textContent = titles[sectionId] || 'Overview';
  }

  // If navigating to comments, refresh table
  if (sectionId === 'comments') {
    renderAllCommentsTable();
  }
}

/**
 * WebSocket Real-time Connection via Socket.io
 */
function initSocket() {
  const statusDot = document.getElementById('liveIndicatorDot');
  const statusText = document.getElementById('socketStatusText');

  try {
    // Attempt socket connection
    state.socket = typeof io !== 'undefined' ? io(API_BASE, { withCredentials: true }) : null;

    if (!state.socket) {
      console.warn('Socket.io library not loaded; operating in HTTP polling mode');
      if (statusDot) statusDot.className = 'status-indicator offline';
      if (statusText) statusText.textContent = 'Polling Mode';
      return;
    }

    state.socket.on('connect', () => {
      console.log('✓ Connected to Real-time Socket Server:', state.socket.id);
      if (statusDot) statusDot.className = 'status-indicator live';
      if (statusText) statusText.textContent = 'Real-time Connected';
    });

    state.socket.on('disconnect', () => {
      console.warn('! Disconnected from Socket Server');
      if (statusDot) statusDot.className = 'status-indicator offline';
      if (statusText) statusText.textContent = 'Reconnecting...';
    });

    // Real-time Event: New comment submitted and analyzed
    state.socket.on('new-comment', (newComment) => {
      console.log('⚡ Real-time event [new-comment] received:', newComment);

      // Add to front of comments list
      state.comments.unshift(newComment);

      // Re-render recent comments & all comments
      renderRecentCommentsTable();
      if (state.activeSection === 'comments') {
        renderAllCommentsTable();
      }

      // Increment notification bell
      incrementNotificationBell();

      // Show toast
      showToast(
        `New ${newComment.sentiment} Comment`,
        `[${newComment.topic}] ${newComment.summary || newComment.text.slice(0, 70)}...`,
        newComment.sentiment.toLowerCase()
      );
    });

    // Real-time Event: Updated stats
    state.socket.on('stats-update', (updatedStats) => {
      console.log('⚡ Real-time event [stats-update] received:', updatedStats);
      state.stats = updatedStats;
      updateUIWithStats(updatedStats);
    });

    // Real-time Event: Comment deleted
    state.socket.on('comment-deleted', ({ id }) => {
      state.comments = state.comments.filter(c => String(c._id) !== String(id));
      renderRecentCommentsTable();
      if (state.activeSection === 'comments') {
        renderAllCommentsTable();
      }
    });

  } catch (err) {
    console.error('Socket initialization failed:', err);
  }
}

/**
 * Fetch and update dashboard metrics from /api/comments/stats
 */
async function loadDashboardStats() {
  try {
    const res = await fetch(`${API_BASE}/api/comments/stats`, { credentials: 'include' });
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) {
      state.stats = json.data;
      updateUIWithStats(json.data);
    }
  } catch (err) {
    console.error('Error fetching dashboard stats:', err);
  }
}

/**
 * Render all statistical cards, distribution charts, topic lists, emotion counters
 */
function updateUIWithStats(stats) {
  const total = stats.total || 0;
  const pos = stats.positive || 0;
  const neg = stats.negative || 0;
  const neu = stats.neutral || 0;

  // 1. Stat Cards
  const elTotal = document.getElementById('statTotal');
  const elPos = document.getElementById('statPositive');
  const elNeg = document.getElementById('statNegative');
  const elNeu = document.getElementById('statNeutral');

  if (elTotal) elTotal.textContent = total.toLocaleString();
  if (elPos) elPos.textContent = pos.toLocaleString();
  if (elNeg) elNeg.textContent = neg.toLocaleString();
  if (elNeu) elNeu.textContent = neu.toLocaleString();

  const posPct = total > 0 ? Math.round((pos / total) * 100) : 0;
  const negPct = total > 0 ? Math.round((neg / total) * 100) : 0;
  const neuPct = total > 0 ? Math.round((neu / total) * 100) : 0;

  const elPosPct = document.getElementById('statPositivePct');
  const elNegPct = document.getElementById('statNegativePct');
  const elNeuPct = document.getElementById('statNeutralPct');

  if (elPosPct) elPosPct.textContent = `${posPct}% of total`;
  if (elNegPct) elNegPct.textContent = `${negPct}% of total`;
  if (elNeuPct) elNeuPct.textContent = `${neuPct}% of total`;

  // 2. Sentiment Distribution Progress Bars & Top Meter
  const barPos = document.getElementById('barFillPos');
  const barNeu = document.getElementById('barFillNeu');
  const barNeg = document.getElementById('barFillNeg');

  if (barPos) barPos.style.width = `${posPct}%`;
  if (barNeu) barNeu.style.width = `${neuPct}%`;
  if (barNeg) barNeg.style.width = `${negPct}%`;

  const progPos = document.getElementById('progPos');
  const progNeg = document.getElementById('progNeg');
  const progNeu = document.getElementById('progNeu');

  if (progPos) progPos.style.width = `${posPct}%`;
  if (progNeg) progNeg.style.width = `${negPct}%`;
  if (progNeu) progNeu.style.width = `${neuPct}%`;

  const textPosCount = document.getElementById('textPosCount');
  const textNegCount = document.getElementById('textNegCount');
  const textNeuCount = document.getElementById('textNeuCount');

  if (textPosCount) textPosCount.textContent = `${pos} (${posPct}%)`;
  if (textNegCount) textNegCount.textContent = `${neg} (${negPct}%)`;
  if (textNeuCount) textNeuCount.textContent = `${neu} (${neuPct}%)`;

  // 3. Topic Distribution Bars
  const topics = stats.byTopic || {};
  const topicKeys = ['Healthcare', 'Education', 'Transportation', 'Public Services', 'Other'];

  topicKeys.forEach(key => {
    const count = topics[key] || 0;
    const safeKey = key.replace(/\s+/g, '');
    const countEl = document.getElementById(`topicCount${safeKey}`);
    const progEl = document.getElementById(`topicProg${safeKey}`);
    const badgeEl = document.getElementById(`badgeTopic${safeKey}`);

    if (countEl) countEl.textContent = count;
    if (badgeEl) badgeEl.textContent = `${count} Comments`;
    if (progEl) {
      const pct = total > 0 ? Math.round((count / total) * 100) : 0;
      progEl.style.width = `${pct}%`;
    }
  });

  // 4. Emotion Cards
  const emotions = stats.byEmotion || {};
  const emotionKeys = ['Happy', 'Angry', 'Sad', 'Neutral', 'Concerned'];
  const totalEmotions = emotionKeys.reduce((sum, emotion) => sum + (Number(emotions[emotion]) || 0), 0);
  const totalEmotionEl = document.getElementById('totalEmotionCount');

  if (totalEmotionEl) totalEmotionEl.textContent = totalEmotions.toLocaleString();

  emotionKeys.forEach(em => {
    const count = emotions[em] || 0;
    const countEl = document.getElementById(`countEmotion${em}`);
    const pctEl = document.getElementById(`pctEmotion${em}`);
    const pct = total > 0 ? Math.round((count / total) * 100) : 0;

    if (countEl) countEl.textContent = count;
    if (pctEl) pctEl.textContent = `${pct}% of feedback`;
  });

  // 5. Priority Analysis Cards
  const priorities = stats.byPriority || {};
  const elPriHigh = document.getElementById('priorityCountHigh');
  const elPriMed = document.getElementById('priorityCountMedium');
  const elPriLow = document.getElementById('priorityCountLow');

  if (elPriHigh) elPriHigh.textContent = priorities.High || 0;
  if (elPriMed) elPriMed.textContent = priorities.Medium || 0;
  if (elPriLow) elPriLow.textContent = priorities.Low || 0;

  // 6. Reports Section Summary
  const reportScore = document.getElementById('reportScore');
  const reportTopSector = document.getElementById('reportTopSector');
  const reportCriticalCount = document.getElementById('reportCriticalCount');

  if (reportScore) {
    const satisfaction = total > 0 ? Math.round(((pos + 0.5 * neu) / total) * 100) : 0;
    reportScore.textContent = `${satisfaction}%`;
  }

  if (reportTopSector) {
    let topTopic = 'None';
    let max = -1;
    for (const [top, c] of Object.entries(topics)) {
      if (c > max && c > 0) {
        max = c;
        topTopic = top;
      }
    }
    reportTopSector.textContent = topTopic;
  }

  if (reportCriticalCount) {
    reportCriticalCount.textContent = priorities.High || 0;
  }
}

/**
 * Fetch and populate recent comments from /api/comments
 */
async function loadRecentComments(showLoader = true) {
  const tbody = document.getElementById('recentCommentsTableBody');

  if (showLoader && tbody && state.comments.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center py-4">
          <div class="table-loader"><i class="fa-solid fa-circle-notch fa-spin"></i> Loading comments...</div>
        </td>
      </tr>
    `;
  }

  try {
    const res = await fetch(`${API_BASE}/api/comments?limit=50`, { credentials: 'include' });
    if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) {
      state.comments = json.data;
      renderRecentCommentsTable();
      renderAllCommentsTable();
    }
  } catch (err) {
    console.error('Error loading comments:', err);
    if (tbody && state.comments.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6" class="text-center py-4" style="color: #ef4444;">
            <i class="fa-solid fa-triangle-exclamation"></i> Could not connect to API server. Ensure backend is running.
          </td>
        </tr>
      `;
    }
  }
}

/**
 * Render recent comments table with filtering
 */
function renderRecentCommentsTable() {
  const tbody = document.getElementById('recentCommentsTableBody');
  if (!tbody) return;

  let list = [...state.comments];
  if (state.recentFilter !== 'all') {
    list = list.filter(c => c.sentiment === state.recentFilter);
  }

  // Display top 10 recent
  list = list.slice(0, 10);

  if (list.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center py-4" style="color: #94a3b8;">
          No comments matching the selected filter.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = list.map(c => `
    <tr>
      <td>
        <div class="comment-cell-text">${escapeHtml(c.text)}</div>
        <div class="comment-cell-meta">
          <span><i class="fa-regular fa-clock"></i> ${formatTimeAgo(c.createdAt)}</span>
          ${c.policyTitle ? `<span class="comment-cell-summary">Policy: ${escapeHtml(c.policyTitle)}</span>` : ''}
          ${c.summary ? `<span class="comment-cell-summary">"${escapeHtml(c.summary)}"</span>` : ''}
        </div>
      </td>
      <td>
        <span class="badge-tag ${escapeHtml(c.sentiment)}">
          ${getSentimentIcon(c.sentiment)} ${escapeHtml(c.sentiment)}
        </span>
      </td>
      <td>
        <span class="topic-tag">
          ${getTopicIcon(c.topic)} ${escapeHtml(c.topic)}
        </span>
      </td>
      <td>
        <span>${getEmotionEmoji(c.emotion)} ${escapeHtml(c.emotion)}</span>
      </td>
      <td>
        <span class="priority-pill ${escapeHtml(c.priority)}">${escapeHtml(c.priority)}</span>
      </td>
      <td style="text-align: right;">
        ${state.user && String(c.userId) === String(state.user.id) ? `<button class="btn btn-danger btn-sm" onclick="handleDeleteComment('${c._id}')" title="Delete comment"><i class="fa-regular fa-trash-can"></i></button>` : ''}
      </td>
    </tr>
  `).join('');
}

/**
 * Filter buttons for Recent Comments
 */
function filterRecentTable(sentiment) {
  state.recentFilter = sentiment;
  document.querySelectorAll('.filter-chip').forEach(chip => {
    if (chip.getAttribute('data-filter') === sentiment) {
      chip.classList.add('active');
    } else {
      chip.classList.remove('active');
    }
  });
  renderRecentCommentsTable();
}

/**
 * Render "All Comments" Database table with search & multi-select filtering
 */
function renderAllCommentsTable() {
  const tbody = document.getElementById('allCommentsTableBody');
  if (!tbody) return;

  const searchInput = document.getElementById('commentsSearchInput');
  const filterTopic = document.getElementById('filterTopicSelect');
  const filterSentiment = document.getElementById('filterSentimentSelect');
  const filterPriority = document.getElementById('filterPrioritySelect');

  const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const selTopic = filterTopic ? filterTopic.value : '';
  const selSentiment = filterSentiment ? filterSentiment.value : '';
  const selPriority = filterPriority ? filterPriority.value : '';

  let list = state.comments.filter(c => {
    const matchQuery = !query || 
      c.text.toLowerCase().includes(query) ||
      (c.summary && c.summary.toLowerCase().includes(query)) ||
      (c.keywords && c.keywords.some(k => k.toLowerCase().includes(query)));

    const matchTopic = !selTopic || c.topic === selTopic;
    const matchSentiment = !selSentiment || c.sentiment === selSentiment;
    const matchPriority = !selPriority || c.priority === selPriority;

    return matchQuery && matchTopic && matchSentiment && matchPriority;
  });

  if (list.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center py-4" style="color: #94a3b8;">
          No matching comments found in database.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = list.map(c => `
    <tr>
      <td>
        <div class="comment-cell-text">${escapeHtml(c.text)}</div>
        ${c.summary ? `<div class="comment-cell-summary">AI Summary: ${escapeHtml(c.summary)}</div>` : ''}
        ${c.policyTitle ? `<div class="comment-cell-summary">Policy: ${escapeHtml(c.policyTitle)}</div>` : ''}
        ${c.keywords && c.keywords.length > 0 ? `
          <div class="keywords-wrap mt-1">
            ${c.keywords.map(k => `<span class="kw-tag">${escapeHtml(k)}</span>`).join('')}
          </div>
        ` : ''}
      </td>
      <td>
        <span class="badge-tag ${escapeHtml(c.sentiment)}">
          ${getSentimentIcon(c.sentiment)} ${escapeHtml(c.sentiment)}
        </span>
      </td>
      <td>
        <span class="topic-tag">${getTopicIcon(c.topic)} ${escapeHtml(c.topic)}</span>
      </td>
      <td>
        <span>${getEmotionEmoji(c.emotion)} ${escapeHtml(c.emotion)}</span>
      </td>
      <td>
        <span class="priority-pill ${escapeHtml(c.priority)}">${escapeHtml(c.priority)}</span>
      </td>
      <td>
        <span style="font-size: 0.78rem; color: #64748b;">${new Date(c.createdAt).toLocaleDateString()}</span>
      </td>
      <td style="text-align: right;">
        ${state.user && String(c.userId) === String(state.user.id) ? `<button class="btn btn-danger btn-sm" onclick="handleDeleteComment('${c._id}')" title="Delete comment"><i class="fa-regular fa-trash-can"></i></button>` : ''}
      </td>
    </tr>
  `).join('');
}

function handleSearchComments() {
  renderAllCommentsTable();
}

/**
 * Handle form submission in "Analyze Comment" section
 */
async function handleAnalyzeSubmit(event) {
  event.preventDefault();

  const textarea = document.getElementById('feedbackText');
  const btn = document.getElementById('btnAnalyzeSubmit');
  const btnText = document.getElementById('btnAnalyzeText');
  const statusBadge = document.getElementById('resultStatusBadge');

  const text = textarea ? textarea.value.trim() : '';
  if (!text) return;

  // Set loading state
  if (btn) btn.disabled = true;
  if (btnText) btnText.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Analyzing with AI...';
  if (statusBadge) {
    statusBadge.textContent = 'Processing...';
    statusBadge.style.backgroundColor = '#eff6ff';
    statusBadge.style.color = '#1d4ed8';
  }

  try {
    const res = await fetch(`${API_BASE}/api/comments/analyze`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        policyId: document.getElementById('policySelect').value
      })
    });

    const json = await res.json();

    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Analysis failed');
    }

    const comment = json.data;

    // Display result in AI card
    displayAnalysisResult(comment);

    // Refresh dashboard stats and comments
    loadDashboardStats();
    loadRecentComments(false);

    showToast('Analysis Completed', `Sentiment: ${comment.sentiment} (${comment.topic})`, comment.sentiment.toLowerCase());

  } catch (err) {
    console.error('Error during AI analysis:', err);
    alert('Failed to analyze comment: ' + err.message);
    if (statusBadge) {
      statusBadge.textContent = 'Error';
      statusBadge.style.backgroundColor = '#fef2f2';
      statusBadge.style.color = '#ef4444';
    }
  } finally {
    if (btn) btn.disabled = false;
    if (btnText) btnText.innerHTML = 'Analyze Feedback';
  }
}

/**
 * Render the parsed analysis in the right-side Result Card
 */
function displayAnalysisResult(data) {
  const emptyState = document.getElementById('emptyResultState');
  const details = document.getElementById('resultDetails');
  const statusBadge = document.getElementById('resultStatusBadge');

  if (emptyState) emptyState.style.display = 'none';
  if (details) details.style.display = 'flex';
  if (statusBadge) {
    statusBadge.textContent = 'Classified';
    statusBadge.style.backgroundColor = '#ecfdf5';
    statusBadge.style.color = '#065f46';
  }

  // Sentiment badge
  const resSent = document.getElementById('resSentimentBadge');
  if (resSent) {
    resSent.className = `badge-tag ${data.sentiment}`;
    resSent.innerHTML = `${getSentimentIcon(data.sentiment)} ${data.sentiment}`;
  }

  // Topic badge
  const resTopic = document.getElementById('resTopicBadge');
  if (resTopic) {
    resTopic.className = 'badge-tag';
    resTopic.style.backgroundColor = '#f1f5f9';
    resTopic.style.color = '#1e293b';
    resTopic.innerHTML = `${getTopicIcon(data.topic)} ${data.topic}`;
  }

  // Emotion badge
  const resEmotion = document.getElementById('resEmotionBadge');
  if (resEmotion) {
    resEmotion.className = 'badge-tag';
    resEmotion.style.backgroundColor = '#f8fafc';
    resEmotion.style.color = '#1e293b';
    resEmotion.innerHTML = `${getEmotionEmoji(data.emotion)} ${data.emotion}`;
  }

  // Priority badge
  const resPriority = document.getElementById('resPriorityBadge');
  if (resPriority) {
    resPriority.className = `priority-pill ${data.priority}`;
    resPriority.textContent = data.priority;
  }

  // Confidence
  const resConf = document.getElementById('resConfidence');
  const resConfFill = document.getElementById('resConfidenceFill');
  const confVal = data.confidence || 88;
  if (resConf) resConf.textContent = `${confVal}%`;
  if (resConfFill) resConfFill.style.width = `${confVal}%`;

  // Keywords
  const kwContainer = document.getElementById('resKeywordsContainer');
  if (kwContainer) {
    if (data.keywords && data.keywords.length > 0) {
      kwContainer.innerHTML = data.keywords.map(k => `<span class="kw-tag">${escapeHtml(k)}</span>`).join('');
    } else {
      kwContainer.innerHTML = '<span class="kw-tag">general</span>';
    }
  }

  // Summary
  const resSummary = document.getElementById('resSummary');
  if (resSummary) {
    resSummary.textContent = data.summary || 'Citizen feedback analyzed and cataloged successfully.';
  }
}

/**
 * Insert sample feedback presets
 */
function insertSample(index) {
  const textarea = document.getElementById('feedbackText');
  if (textarea && SAMPLE_PRESETS[index]) {
    textarea.value = SAMPLE_PRESETS[index];
    textarea.focus();
  }
}

function clearAnalyzeForm() {
  const textarea = document.getElementById('feedbackText');
  if (textarea) textarea.value = '';

  const emptyState = document.getElementById('emptyResultState');
  const details = document.getElementById('resultDetails');
  const statusBadge = document.getElementById('resultStatusBadge');

  if (emptyState) emptyState.style.display = 'block';
  if (details) details.style.display = 'none';
  if (statusBadge) {
    statusBadge.textContent = 'Awaiting Input';
    statusBadge.style.backgroundColor = '#f1f5f9';
    statusBadge.style.color = '#64748b';
  }
}

/**
 * Delete a comment by ID
 */
async function handleDeleteComment(id) {
  if (!confirm('Are you sure you want to delete this consultation comment?')) {
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/api/comments/${id}`, {
      method: 'DELETE',
      credentials: 'include'
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Delete failed');
    }

    // Remove locally
    state.comments = state.comments.filter(c => String(c._id) !== String(id));
    renderRecentCommentsTable();
    renderAllCommentsTable();
    loadDashboardStats();

    showToast('Deleted', 'Comment removed from database', 'neutral');
  } catch (err) {
    console.error('Error deleting comment:', err);
    alert('Failed to delete comment: ' + err.message);
  }
}

/**
 * Quick filter shortcut from Topic cards
 */
function filterCommentsByTopic(topicName) {
  navigateTo('comments');
  const filterTopic = document.getElementById('filterTopicSelect');
  if (filterTopic) {
    filterTopic.value = topicName;
    renderAllCommentsTable();
  }
}

/**
 * Quick filter shortcut from Priority cards
 */
function filterCommentsByPriority(priorityLevel) {
  navigateTo('comments');
  const filterPriority = document.getElementById('filterPrioritySelect');
  if (filterPriority) {
    filterPriority.value = priorityLevel;
    renderAllCommentsTable();
  }
}

/**
 * Export all comments as CSV file
 */
function exportCommentsCSV() {
  if (state.comments.length === 0) {
    alert('No comments available to export.');
    return;
  }

  const headers = ['ID', 'Text', 'Policy', 'Sentiment', 'Topic', 'Emotion', 'Priority', 'Confidence', 'Keywords', 'Summary', 'CreatedAt'];
  const rows = state.comments.map(c => [
    c._id,
    `"${(c.text || '').replace(/"/g, '""')}"`,
    `"${(c.policyTitle || '').replace(/"/g, '""')}"`,
    c.sentiment,
    c.topic,
    c.emotion,
    c.priority,
    c.confidence,
    `"${(c.keywords || []).join(', ')}"`,
    `"${(c.summary || '').replace(/"/g, '""')}"`,
    c.createdAt
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `e_consultation_comments_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Toast Notification Helper
 */
function showToast(title, message, type = 'neutral') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let icon = '<i class="fa-solid fa-bell toast-icon"></i>';
  if (type === 'positive') icon = '<i class="fa-solid fa-circle-check toast-icon text-green"></i>';
  if (type === 'negative') icon = '<i class="fa-solid fa-circle-exclamation toast-icon text-red"></i>';
  if (type === 'neutral') icon = '<i class="fa-solid fa-circle-info toast-icon text-amber"></i>';

  toast.innerHTML = `
    ${icon}
    <div class="toast-body">
      <div class="toast-title">${escapeHtml(title)}</div>
      <div class="toast-msg">${escapeHtml(message)}</div>
    </div>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}

function incrementNotificationBell() {
  state.unreadNotifications++;
  const badge = document.getElementById('bellCount');
  if (badge) {
    badge.textContent = state.unreadNotifications;
    badge.style.display = 'flex';
  }
}

/**
 * Visual Helpers
 */
function getSentimentIcon(sentiment) {
  if (sentiment === 'Positive') return '<i class="fa-solid fa-arrow-trend-up"></i>';
  if (sentiment === 'Negative') return '<i class="fa-solid fa-arrow-trend-down"></i>';
  return '<i class="fa-solid fa-minus"></i>';
}

function getTopicIcon(topic) {
  switch (topic) {
    case 'Healthcare': return '<i class="fa-solid fa-hospital-user text-blue"></i>';
    case 'Education': return '<i class="fa-solid fa-graduation-cap text-indigo"></i>';
    case 'Transportation': return '<i class="fa-solid fa-bus text-teal"></i>';
    case 'Public Services': return '<i class="fa-solid fa-building-columns text-purple"></i>';
    default: return '<i class="fa-solid fa-cubes text-gray"></i>';
  }
}

function getEmotionEmoji(emotion) {
  switch (emotion) {
    case 'Happy': return '😄';
    case 'Angry': return '😡';
    case 'Sad': return '😢';
    case 'Neutral': return '😐';
    case 'Concerned': return '😟';
    default: return '💬';
  }
}

function formatTimeAgo(dateString) {
  if (!dateString) return '';
  const date = new Date(dateString);
  const now = new Date();
  const diffSec = Math.floor((now - date) / 1000);

  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  return `${diffDays}d ago`;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
